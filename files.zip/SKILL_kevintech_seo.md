---
name: kevintech-seo
description: >
  Skill SEO complet pour le site KevinTech&Co (kevintechco.github.io/kevintech.co/).
  Utilise ce skill pour toute demande d'amélioration SEO, ajout de contenu, création
  de nouvelles pages locales, mise à jour des schemas, optimisation des balises meta,
  ou toute modification du fichier index.html de KevinTech&Co.
  Déclenche aussi pour "améliore le site", "ajoute une page", "nouvelle ville",
  "FAQ", "schema", "Google Business", "mots-clés", "contenu", "référencement".
---

# Skill : KevinTech&Co — SEO & Contenu Web

## Contexte business

**Entreprise :** KevinTech&Co  
**Activité :** Réparation iPhone, smartphone, PC gaming, récupération de données  
**Gérant :** M. Leclercq  
**Adresse :** 187 rue des Gaillards, 60700 Sacy-le-Grand (Oise)  
**Téléphone :** 07 71 66 83 64 (+33771668364)  
**SIRET :** 940 964 414 00012  
**Horaires :** Lundi–Samedi, 9h00–18h30  
**URL actuelle :** https://kevintechco.github.io/kevintech.co/  
**Domaine cible :** kevintech.co (à acquérir)  
**Statut :** Micro-entreprise indépendante

---

## Offres exclusives et différenciants clés

| Offre | Détail |
|-------|--------|
| Garantie Casse 6 mois | Unique dans l'Oise. iPhone X et +. Pièce offerte, forfait 70€, jusqu'à 3x |
| Programme GAPP | Pièces Apple d'origine certifiées. True Tone et Face ID 100% préservés |
| Gammes d'écrans | Économie / Soft OLED / Reconditionné / Service Pack |
| PC Gaming | Montage sur mesure, diagnostic, nettoyage thermique, install Windows |
| Récupération données | SSD, HDD interne, disque dur externe. Micro-soudure carte mère |

---

## Zone géographique & mots-clés locaux prioritaires

**Ville principale :** Sacy-le-Grand (60700)  
**Villes secondaires :** Creil · Senlis · Chantilly · Compiègne · Verberie · Pont-Sainte-Maxence · Nogent-sur-Oise

**Mots-clés stratégiques par priorité :**

| Priorité | Mot-clé | Difficulté |
|----------|---------|-----------|
| 🔴 Max | réparation iphone sacy-le-grand | Très facile |
| 🔴 Max | réparation ecran iphone oise | Moyen |
| 🟠 Haute | réparation iphone creil | Facile |
| 🟠 Haute | réparateur iphone senlis | Facile |
| 🟡 Moyenne | batterie iphone oise | Facile |
| 🟡 Moyenne | réparation samsung galaxy oise | Facile |
| 🟢 Niche | montage pc gaming oise | Très facile |
| 🟢 Niche | récupération données ssd oise | Très facile |
| 🟢 Niche | micro-soudure smartphone oise | Quasi-absent |

---

## Stack technique du site

- **Framework :** Vanilla HTML/CSS/JS, page unique (SPA)
- **Hébergement :** GitHub Pages (kevintechco.github.io)
- **Polices :** Plus Jakarta Sans (Google Fonts)
- **Icônes :** Font Awesome 6.5.1 (CDN, chargement différé)
- **Couleurs CSS** (variables à respecter absolument) :

```css
--bg: #050505
--accent: #E63946          /* rouge — iPhone, prix, alertes */
--apple-blue: #0071e3      /* sections Apple/GAPP */
--android-green: #3DDC84   /* Samsung/Android/délais */
--pc-blue: #00C8FF         /* PC Gaming */
--data-purple: #A855F7     /* récupération données */
--text-main: #ffffff
--text-dim: #a1a1a6
--glass: rgba(255,255,255,0.03)
--glass-border: rgba(255,255,255,0.1)
```

---

## Schemas.org en place (à maintenir à jour)

1. **WebSite** — présent
2. **LocalBusiness** — complet (adresse, geo, horaires, areaServed, offers, reviews)
3. **BreadcrumbList** — présent
4. **FAQPage** — 7 questions (doit correspondre exactement aux `<details>` visibles)

⚠️ **Règle critique :** Le schema FAQPage doit toujours être synchronisé avec les `<details>` HTML visibles. Si on ajoute/modifie une question visible, mettre à jour le JSON-LD en même temps.

---

## Corrections SEO déjà appliquées (ne pas réintroduire)

| Problème | Statut |
|----------|--------|
| H1 caché (clip rect) | ✅ Supprimé — H1 visible dans `<h1 class="hero-title">` |
| Preload sur mauvaise image (IMG_0816) | ✅ Corrigé → IMG_0003.jpg |
| Double fetchpriority="high" | ✅ Corrigé — uniquement sur IMG_0003 |
| Meta description trop longue (207 chars) | ✅ Ramenée à 155 chars |
| Sections SPA non indexables | ✅ Corrigé — `display:block` par défaut, JS en defer |
| FAQPage schema sans contenu visible | ✅ 7 `<details>` visibles + schema synchronisé |
| reviewCount arbitraire ("50") | ✅ Mis à 7 (avis réels dans le code) |

---

## Checklist mensuelle SEO (à faire chaque mois)

### Mois 1 — Fondations
- [ ] Acheter le domaine kevintech.co (~12€/an OVH)
- [ ] Migrer vers un hébergement avec domaine propre (Netlify/Vercel gratuit)
- [ ] Mettre à jour canonical, og:url, og:image, schemas avec nouvelle URL
- [ ] Vérifier Google Search Console + soumettre sitemap
- [ ] Compléter fiche Google Business à 100% (photos, description, Q&A)

### Mois 2 — Contenu & Avis
- [ ] Demander 10+ avis Google via WhatsApp après chaque réparation
- [ ] Répondre à TOUS les avis (positifs et négatifs) sur Google et Pages Jaunes
- [ ] Mettre à jour reviewCount dans le Schema LocalBusiness
- [ ] Créer image og:image 1200×630px dédiée (photo atelier en format paysage)
- [ ] Ajouter 2-3 nouvelles questions à la FAQ sur les sujets recherchés

### Mois 3 — Pages locales & Backlinks
- [ ] Créer page dédiée /creil (réparation iPhone Creil — mot-clé fort)
- [ ] Créer page dédiée /senlis (réparateur iPhone Senlis)
- [ ] S'inscrire sur Yelp, Trustpilot, Cylex pour des backlinks locaux
- [ ] Proposer un article à un blog local ou forum Oise (backlink)
- [ ] Vérifier cohérence NAP sur toutes les plateformes (PJ, GBP, site, réseaux)

---

## Template : nouvelle page locale

Quand l'utilisateur demande une page pour une ville (ex: Creil), générer ce template :

```html
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Réparation iPhone [VILLE] (60) – KevinTech&Co | Sacy-le-Grand</title>
  <meta name="description" content="Réparation iPhone & smartphone à [VILLE] (Oise). Apportez votre appareil à Sacy-le-Grand, à [Xkm] de [VILLE]. Garantie casse 6 mois exclusive. Devis gratuit.">
  <link rel="canonical" href="https://kevintech.co/[ville-slug]">
  <!-- Schema LocalBusiness identique + areaServed ajusté -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "KevinTech&Co",
    "areaServed": [{"@type": "City", "name": "[VILLE]"}, ...],
    ...
  }
  </script>
</head>
<body>
  <h1>Réparation iPhone & smartphone à [VILLE] – KevinTech&Co</h1>
  <p>Vous cherchez un réparateur iPhone à [VILLE] dans l'Oise ? KevinTech&Co est votre atelier de proximité, situé à [X minutes] de [VILLE] à Sacy-le-Grand.</p>
  <!-- Reprendre structure complète de index.html avec contenu géo-spécifique -->
</body>
</html>
```

---

## Template : nouvelle question FAQ

Ajouter dans la section `<section id="faq">` ET dans le JSON-LD FAQPage :

```html
<details class="faq-item" itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
    <summary>
        <span>
            <span class="faq-tag" style="background:rgba([R],[G],[B],.1); color:var(--[COULEUR]);">[EMOJI] [CATÉGORIE]</span><br>
            <span itemprop="name">[QUESTION EN FRANÇAIS ?]</span>
        </span>
        <span class="faq-icon" style="background:rgba([R],[G],[B],.1); color:var(--[COULEUR]);"><i class="fas fa-chevron-down" aria-hidden="true"></i></span>
    </summary>
    <div class="faq-body" itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
        <p itemprop="text">[RÉPONSE avec <strong>mots-clés</strong> et noms de <strong>villes</strong> naturellement intégrés.]</p>
    </div>
</details>
```

---

## Règles SEO absolues pour KevinTech&Co

1. **Ne jamais cacher du contenu** avec `clip:rect`, `visibility:hidden` ou `display:none` si ce contenu est censé être indexé
2. **Un seul H1 par page**, visible, contenant "iPhone" + "Sacy-le-Grand" ou la ville cible
3. **Schema FAQPage = contenu visible** — toujours synchroniser les deux
4. **fetchpriority="high"** uniquement sur la 1ère image chargée (IMG_0003.jpg sur la homepage)
5. **Meta description : 150–160 caractères max** — compter avant de valider
6. **NAP identique partout** : "KevinTech&Co", "187 rue des Gaillards, 60700 Sacy-le-Grand", "07 71 66 83 64"
7. **Canonical à mettre à jour** dès changement de domaine — vérifier dans 3 endroits : `<link rel="canonical">`, `og:url`, tous les schemas
8. **reviewCount dans LocalBusiness** = nombre réel d'avis vérifiables sur Google/PJ
